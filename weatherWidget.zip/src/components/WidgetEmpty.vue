<template>
  <div class="message">
    Add the city in which you want to know the weather in the settings
  </div>
</template>

<style lang="scss" scoped>
.message {
  color: white;
  text-align: center;
  padding: 60px 20px;
}
</style>
